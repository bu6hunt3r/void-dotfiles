## Sourcing ##

# Load automatic configuration
config.load_autoconfig()
# Load custom theme
config.source('theme.py')

## Misc. ##

# Always restore open sites when qutebrowser is reopened.
c.auto_save.session = True

# Prefer dark color schemes
c.colors.webpage.preferred_color_scheme = 'dark'
#c.colors.webpage.darkmode.enabled = True

# Require a confirmation before quitting the application if downloads are active.
c.confirm_quit = ["downloads"]

# Enable hidpi mode
c.qt.highdpi = True

# Enable smooth scrolling
c.scrolling.smooth = True

## Content ##

# Don't view pdf files in-browser
c.content.pdfjs = False

# Disable autoplay
c.content.autoplay = False

# Anti-fingerprinting
c.content.headers.user_agent = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.75 Safari/537.36'
c.content.headers.accept_language = 'en-US,en;q=0.5'
c.content.headers.custom = {"accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"}
c.content.cookies.accept = "no-3rdparty"

# Adblock filter lists
c.content.blocking.adblock.lists = [
        "https://easylist.to/easylist/easylist.txt",
        "https://easylist.to/easylist/easyprivacy.txt",
        "https://secure.fanboy.co.nz/fanboy-annoyance.txt",
        "https://easylist-downloads.adblockplus.org/antiadblockfilters.txt",
        "https://easylist-downloads.adblockplus.org/abp-filters-anti-cv.txt",
]


## Downloads ##

# Put the download bar at the bottom of the screen
c.downloads.position = "bottom"

# Remove finished downloads from the download bar after 5 minutes
c.downloads.remove_finished = 300000


## Hints ##

# Add full keyboard layout to hint chars
# This is a bad idea but works nicely as typing practice
# Now adapted for my redox layout, so somewhat nonsensical for other layouts
c.hints.chars =  'asdfghjkl;\'' + 'qwerty[]uiop-' + 'zxcvbnm,./\\' + '`1234567890='

# Don't lead hint mode when page loads
c.hints.leave_on_load = False


## Tabs ##

# Load the default page after closing the last tab
c.tabs.last_close = "close"

# Hide the tab bar if only one tab is open
c.tabs.show = "multiple"

# Set a maximum tab width so small numbers of tabs aren't so huge
c.tabs.max_width = 250


## URL ##

# Set default_page to blank page
c.url.default_page = "about:blank"

# Set up search engines
c.url.searchengines = {
  "DEFAULT": "https://duckduckgo.com?q={}",
  "au":      "https://aur.archlinux.org/packages/?K={}",
  "aw":      "https://wiki.archlinux.org/?search={}",
  "bw":      "https://bookwyrm.social/search?q={}",
  "dd":      "https://duckduckgo.com?q={}",
  "df":      "https://dwarffortresswiki.org?search={}",
  "g":       "https://www.google.com/search?q={}",
  "gh":      "https://github.com/search?q={}",
  "gm":      "https://mail.google.com/mail/u/0/#search/{}",
  "gp":      "https://photos.google.com/search/{}",
  "gr":      "https://www.goodreads.com/search?q={}",
  "hoo":     "https://hoogle.haskell.org/?hoogle={}",
  "keep":    "https://keep.google.com/u/0/#search/text%253D{}",
  "map":     "https://www.google.com/maps/search/{}",
  "re":      "https://teddit.net/r/all/search?q={}",
  "sg":      "https://app.thestorygraph.com/browse?search_term={}",
  "sp":      "https://startpage.com/sp/search?query={}",
  "tw":      "https://twitter.com/search?q={}",
  "yt":      "https://www.youtube.com/results?search_query={}"
}
config.bind('<Ctrl-Shift-d>', 'hint links spawn --verbose mpv {hint-url}')

# Bindings for cycling through CSS stylesheets from Solarized Everything CSS:
# https://github.com/alphapapa/solarized-everything-css
config.bind(',ap', 'config-cycle content.user_stylesheets ~/.config/qutebrowser/stylesheets/apprentice-all-sites.css ""')
config.bind(',dr', 'config-cycle content.user_stylesheets ~/.config/qutebrowser/stylesheets/darculized-all-sites.css ""')
config.bind(',gr', 'config-cycle content.user_stylesheets ~/.config/qutebrowser/stylesheets/gruvbox-all-sites.css ""')
config.bind(',sd', 'config-cycle content.user_stylesheets ~/.config/qutebrowser/stylesheets/solarized-dark-all-sites.css ""')
config.bind(',sl', 'config-cycle content.user_stylesheets ~/.config/qutebrowser/stylesheets/solarized-light-all-sites.css ""')
