c.fonts.default_family='JetBrains Mono'
c.fonts.tabs.selected='12pt FontAwesome'
c.fonts.tabs.unselected='12pt FontAwesome'
c.fonts.completion.category='JetBrains Mono'
c.fonts.completion.entry='12pt JetBrains Mono'
c.fonts.contextmenu='JetBrains Mono'
c.fonts.debug_console='JetBrains Mono'
c.fonts.default_family='JetBrains Mono'
c.fonts.downloads='JetBrains Mono'
c.fonts.hints='12pt JetBrains Mono'
c.fonts.keyhint='12pt JetBrains Mono'
c.fonts.messages.error='JetBrains Mono'
c.fonts.messages.info='JetBrains Mono'
c.fonts.messages.warning='JetBrains Mono'
c.fonts.prompts='JetBrains Mono'
c.fonts.statusbar='12pt JetBrains Mono'

magenta = "#ea00d9"
dark = "#000b1e"
c.colors.statusbar.command.fg = magenta
c.colors.contextmenu.menu.bg = dark
c.colors.contextmenu.menu.fg = magenta

c.colors.statusbar.insert.bg = dark
c.colors.statusbar.insert.fg = magenta
c.colors.statusbar.progress.bg = dark
c.colors.statusbar.url.fg = magenta
c.colors.statusbar.url.success.http.fg = magenta
c.colors.statusbar.url.success.https.fg = magenta
c.colors.tabs.selected.even.fg = magenta
c.colors.tabs.selected.odd.fg = magenta
c.colors.tabs.odd.bg = dark
c.colors.tabs.even.bg = dark

c.colors.completion.fg = magenta
c.colors.completion.category.fg = magenta
c.colors.completion.category.bg = dark
c.colors.completion.even.bg = dark
c.colors.completion.odd.bg = dark
c.colors.completion.item.selected.bg = "#000000"
c.colors.completion.item.selected.fg = magenta

c.colors.hints.bg = magenta
